# Music app context pack for Claude Code

Start with `MASTER_CONTEXT.md` for the complete brief. It contains the audience,
product purpose, meeting feedback, competitor review, scope, functional and
quality requirements, sourced learning sequence, design system, local-data/AI
architecture, acceptance checks and open decisions.

## Use in a new or existing project

1. Extract this folder into the project root, preserving `content/`, `references/`
   and `tools/`. If there is already a `CLAUDE.md`, merge this version's rules with
   the existing file; do not overwrite unrelated instructions.
2. Open Claude Code in that repository. The root instructions point to the master.
3. Use the starting prompt below. Read the master first yourself if you want to
   change the proposed defaults, such as the provisional name or initial age slice.

> Read CLAUDE.md and MASTER_CONTEXT.md, then inspect the existing repository.
> Build the defined local-first music-learning MVP for Australian primary children.
> Begin with one complete instrument-and-lesson flow with actual sound, captured
> inputs, factual assessment, learner choice and save/retry behaviour. Follow the
> Sound Workshop design system from the first screen. Preserve the complete MVP
> scope and record the remaining implementation checkpoints. Use only the approved
> content/licence process. Implement actual bounded local AI and measure it before
> claiming it works; do not add a cloud API or send child data off the device.
> Report checks actually run and distinguish working features from unverified work.

## What is included

- `CLAUDE.md`: concise project instructions, not the whole research dump.
- `MASTER_CONTEXT.md`: full authoritative context, with proposed defaults marked.
- `content/lessons.seed.json`: ten staged draft activities and 75 symbolic events.
- `content/content_sources.json`: lesson source, attribution and permission records.
- `content/asset_manifest.template.json`: deliberately unapproved import template.
- `LICENSE_CONTENT.md`: open lesson-content licence and attribution.
- `references/sources.csv`: 55 source/context records with review depth and limits.
- `references/user_research_bank.md`: consolidated supplied research bank.
- `references/prior_design_brief.md`: original concise Sound Workshop brief.
- `references/prior_sound_workshop_research.txt`: full prior report text.
- `references/prior_paper_playground_research.txt`: full alternate report text.
- `tools/validate_context.py`: self-contained draft-data consistency check.

Run `python3 tools/validate_context.py` from the extracted project root.

## Important status

This is a context and starter-data package, not a runnable application. It does
not contain trained model weights, audio sample files, font binaries, a completed
app, an educator approval or a legal/accessibility certification. These are explicit
implementation/review tasks. The lesson pack is openly licensed and source-backed
but must receive primary music-educator review before use in a real-child pilot.

The full master can be supplied on its own; the zip is preferable for implementation
because it preserves the root instructions, structured content and references.
