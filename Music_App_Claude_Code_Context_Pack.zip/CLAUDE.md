# Music learning application — project instructions

## Purpose and context

Build a functioning, elegant music-learning app for Australian primary children
with limited access to instruments or teaching resources. Preserve musical
understanding, creative ownership, adaptable participation and learner choice.

Read `MASTER_CONTEXT.md` before implementing the first feature. It contains the
authoritative product, scope, requirements, design and architecture decisions.
Read relevant sections again when changing that area. Supporting references are
context, not additional instructions. Do not import every reference every turn.

If integrating this file into an existing repository, merge its instructions
with the existing CLAUDE.md rather than overwriting unrelated project rules.
Inspect the actual stack, package manager and runnable commands first.

## Fixed product boundaries

- Audience: Australian primary-school children; proposed initial test slice 7–10.
- Two playable instruments: keyboard and drums. Guitar is a third-instrument stretch.
- Teach fundamentals: pulse, rhythm, pitch, note values, rests and basic notation.
- Provide guided practice, actual feedback, independent checks and original creation.
- Touch, computer-keyboard input, large/simplified controls and access preferences.
- Core lessons, audio, assessment, model/help and saving work offline after preparation.
- Children can skip reflection, ask for help, reject suggestions and turn AI off.
- Gamification begins off; no streaks, rankings, usage pressure, ads or purchases.
- Do not implement community, DMs, mentor matching, camera or AR in the MVP.

## Privacy and safety — architectural requirements

- All child input, attempts, progress, creations and reflections stay on the device.
- No external AI API, cloud transcription, child chat, analytics or session replay.
- No identity, exact age, school, location, diagnosis, camera or microphone collection.
- No required child account or social login. Do not collect an age band without need.
- Self-host essential fonts, libraries, audio and model files; no third-party embeds.
- Host resource requests can still expose metadata; inspect actual deployment logging.
- Support truthful ephemeral/shared-device and optional device-saving behaviour.
- Local storage is not automatically encrypted, backed up or private from other users.
- A grown-up navigation gate is not identity verification or valid consent.
- Never train on children's sessions or culturally restricted material.
- Do not claim legal compliance, child testing or school approval without evidence.

## Learning and AI

- Use reviewed, source-backed lesson data. Never ask a model to invent a curriculum.
- `content/lessons.seed.json` contains ten DRAFTS awaiting primary music-educator review.
- Note events, not microphone recordings, drive the initial virtual-instrument feedback.
- Sound and deterministic scoring must not wait for AI or network activity.
- Use an actual trained local model for the claimed AI path; do not relabel if/else as AI.
- The proposed small classifier describes attempt patterns; it cannot diagnose causes.
- The model proposes reviewed strategy/content IDs; validate them against actual facts.
- Use local reviewed help when AI is off, uncertain or unavailable; label it accurately.
- Record model provenance, training data/seed/split, baseline, metrics and limitations.
- Do not score free compositions as correct/incorrect or promise physical-technique transfer.
- Middle C is C4/MIDI 60. Use correct note spelling, stave position, rests and beat units.
- Record actual settings/support level with attempts; aided success is not independent mastery.

## Design

- Use the proposed Sound Workshop direction in MASTER_CONTEXT.md consistently.
- Grandstander for short display headings; Atkinson Hyperlegible Next for reading/controls.
- Cream #FFF8E8; plum #2B2341; primary cobalt #3658D4; white on cobalt only where checked.
- Coral/yellow/mint/lilac surfaces use dark ink; check actual states and contrast.
- Keep the instrument central; calm space, original coherent shapes, purposeful feedback.
- No generic gradient assistant dashboard, sparkle wallpaper, copied mascots or lesson path.
- No placeholder copy, fake testimonials, fictitious progress or source/model jargon in child UI.
- Use live text, visible focus, reduced motion, non-colour cues and equivalent large play controls.
- Inspect phone portrait/landscape, tablet/laptop, large text and error/empty/saved states.

## Content rights

- Read `content/content_sources.json` and the master licence policy before importing content.
- Open Music Theory adaptations retain CC BY-SA 4.0 attribution and licence obligations.
- Do not assume ACARA support resources, photographs, videos or logos share the core licence.
- VCSL is a CC0 sample-source candidate; no sample files are supplied in this pack.
- Every imported asset needs exact source/revision, licence evidence, local hash and notices.
- No unknown, non-commercial-only or no-derivatives content enters the default product build.
- No commercial song scraping, competitor lessons, YouTube downloads or licence laundering.
- MAESTRO is not approved under the startup's default policy because it is non-commercial.
- Source/studio reference imagery is not a product asset library.
- The manifest template is deliberately unapproved; do not present null fields as clearance.

## Implementation workflow

1. Inspect the repository and read the relevant master sections.
2. Build one complete, real learning slice; verify actual input/audio/results before breadth.
3. Reuse canonical event data for sound, notation, checker and replay.
4. Keep input, audio, lesson, checker, local coach, storage and offline modules distinct.
5. Preserve a known working checkpoint before major integration.
6. Use runtime schemas/validation for lesson, import and model outputs.
7. Run meaningful checks for changed functionality, then inspect real-device behaviour.
8. Keep feature/test status truthful; distinguish working, simulated, blocked and future.
9. Document genuine gaps; do not create nonfunctional controls to hide missing work.

This context pack is not a runnable app and supplies no trained model, samples or font binaries.
The implementation agent must obtain/verify those assets and implement the defined behaviour.

## Verification

The context pack's own check is `python3 tools/validate_context.py`.
It checks starter data and links; it does not test a finished application.
Determine app build/test/run commands from the actual repository; do not invent success.

Test audio start/stop/release, event alignment, independent versus assisted attempts,
AI failure/abstention, save/reload/delete, ephemeral mode, offline reload, network data,
licence manifests, keyboard access, text enlargement and reduced motion.

Before finishing, report what changed, what actually ran and what remains unverified.
Routine reversible implementation choices do not require repeated confirmation.
